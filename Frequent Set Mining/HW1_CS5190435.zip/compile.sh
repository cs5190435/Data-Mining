#!/bin/bash
#Produces the required executable files..
g++ -O3 "$PWD/W1.cpp" -o "$PWD/w1"
g++ -O3 "$PWD/W2.cpp" -o "$PWD/w2"